package ec.edu.espe.movil_quiz

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class QuizTwoActivity : AppCompatActivity() {

    private val quiz = Quiz(
        listOf(
            Question("El bus de la escuela tiene 7 filas de asientos, en cada fila hay 6 asientos. Entonces, el bus de la escuela tiene 38 asientos en total.", listOf("Correcto","Incorrecto"),"Correcto"),
            Question("Lucas tiene 7 canastos, en cada canasto puso 8 manzanas. ¿Cuántas manzanas tiene Lucas?", listOf("56","58","49", "22"),"56"),
            Question("Laura tiene 7 sobrinos y quiere darle 3 globos a cada uno de ellos. Según esto, Laura necesita 20 globos.", listOf("Correcto", "Incorrecto"),"Incorrecto"),
            Question("Un edificio tiene 7 pisos, hay 4 apartamentos en cada piso. ¿Cuántos apartamentos hay en el edificio?", listOf("28","24","32", "39"),"28"),
            Question("La maestra tiene 7 cajas, cada caja contiene 5 libros. ¿Cuántos libros hay en total?", listOf("42", "28", "35", "30"), "35"),
        )
    )



    private lateinit var txtQuestionQuizTwo: TextView
    private lateinit var rgOptionsQuizTwo: RadioGroup
    private lateinit var btnNextQuestionQuizTwo: Button

    private val radioButtons by lazy {
        listOf(
            findViewById<RadioButton>(R.id.rbOptionOneQuizTwo),
            findViewById(R.id.rbOptionTwoQuizTwo),
            findViewById(R.id.rbOptionThreeQuizTwo),
            findViewById(R.id.rbOptionFourQuizTwo)
        )
    }

    private var points = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_two)

        txtQuestionQuizTwo = findViewById(R.id.txtQuestion)
        rgOptionsQuizTwo = findViewById(R.id.rgOptionsQuizTwo)
        btnNextQuestionQuizTwo = findViewById(R.id.btnNextQuestionQuizTwo)

        val btnStartQuizTwo = findViewById<Button>(R.id.btnStartQuizTwo)
        btnStartQuizTwo.setOnClickListener{
            startQuiz()
        }

        btnNextQuestionQuizTwo.setOnClickListener {
            checkAnswer()
        }
    }

    private fun startQuiz() {
        showNextQuestion()
    }

    private fun showNextQuestion() {
        val question = quiz.getNextRandomQuestion()

        if (question != null) {
            txtQuestionQuizTwo.setText(question.text)
            rgOptionsQuizTwo.clearCheck()

            val options = question.options
            radioButtons.forEachIndexed {index, radioButton ->
                if(index < options.size){
                    radioButton.text = options[index]
                    radioButton.visibility = RadioButton.VISIBLE
                }else{
                    radioButton.visibility = RadioButton.INVISIBLE
                }
            }
        }else{
            Toast.makeText(this, "No hay más preguntas", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, QuizScoreActivity::class.java)
            intent.putExtra("score", points)
            startActivity(intent)
        }
    }

    private fun checkAnswer() {
        val checkedRadioButton = radioButtons.find {it.isChecked}

        if (checkedRadioButton != null){
            val answer = checkedRadioButton.text.toString().trim()
            if (quiz.checkAnswer(answer)) {
                Toast.makeText(this, "Correcto", Toast.LENGTH_SHORT).show()
                points++;
            }else{
                 Toast.makeText(this, "Incorrecto", Toast.LENGTH_SHORT).show()
            }
            showNextQuestion()
        }else{
            Toast.makeText(this, "Selecciona una opción", Toast.LENGTH_SHORT).show()
        }
    }
}