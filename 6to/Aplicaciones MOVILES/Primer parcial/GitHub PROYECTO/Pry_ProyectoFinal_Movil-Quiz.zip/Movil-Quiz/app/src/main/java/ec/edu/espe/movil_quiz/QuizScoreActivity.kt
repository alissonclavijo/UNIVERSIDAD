package ec.edu.espe.movil_quiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText

class QuizScoreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_score)

        val lblScore = findViewById<EditText>(R.id.lblScore)
        lblScore.setText(intent.getIntExtra("score", 0).toString())
    }
}