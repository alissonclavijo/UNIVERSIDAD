package ec.edu.espe.movil_quiz

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.Toast
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class QuizOneActivity : AppCompatActivity() {

    private val quiz = Quiz(
        listOf(
            Question("7 x 3", listOf("14", "16", "18", "21"), "21"),
            Question("7 x 7", listOf("49", "63", "48", "39"), "49"),
            Question("7 x 9", listOf("63", "56", "49", "42"), "63"),
            Question("7 x 11", listOf("77", "84", "91", "98"), "77"),
            Question("7 x 13", listOf("91", "98", "104", "111"), "91"),
        )
    )

    private lateinit var txtQuestionQuizOne: EditText
    private lateinit var rgOptionsQuizOne: RadioGroup
    private lateinit var btnNextQuestionQuizOne: Button

    private lateinit var txtTimer: TextView
    private lateinit var countDownTimer: CountDownTimer
    private var timerDuration: Long = 30000

    private val radioButtons by lazy {
        listOf(
            findViewById<RadioButton>(R.id.rbOptionOneQuizOne),
            findViewById(R.id.rbOptionTwoQuizOne),
            findViewById(R.id.rbOptionThreeQuizOne),
            findViewById(R.id.rbOptionFourQuizOne)
        )
    }

    private var points = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_one)

        txtQuestionQuizOne = findViewById(R.id.txtQuestionQuizOne)
        rgOptionsQuizOne = findViewById(R.id.rgOptionsQuizOne)
        btnNextQuestionQuizOne = findViewById(R.id.btnNextQuestionQuizOne)

        txtTimer = findViewById(R.id.txtTimer)
        countDownTimer = createCountDownTimer(timerDuration)

        val btnStartQuizOne = findViewById<Button>(R.id.btnStartQuizOne)
        btnStartQuizOne.setOnClickListener {
            startQuiz()
        }

        btnNextQuestionQuizOne.setOnClickListener {
            checkAnswer()
        }
    }

    private fun mostrarSiguientePregunta() {
        val pregunta = quiz.getNextRandomQuestion()

        if (pregunta != null) {
            txtQuestionQuizOne.setText(pregunta.text)
            rgOptionsQuizOne.clearCheck()

            val opciones = pregunta.options
            radioButtons.forEachIndexed { index, radioButton ->
                radioButton.text = opciones[index]
            }
        } else {
            Toast.makeText(this, "No hay más preguntas", Toast.LENGTH_SHORT).show()
            countDownTimer.cancel()
            val intent = Intent(this, QuizScoreActivity::class.java)
            intent.putExtra("score", points)
            startActivity(intent)
        }
    }

    private fun startQuiz() {
        resetCountDownTimer()
        mostrarSiguientePregunta()
    }

    private fun checkAnswer() {
        val checkedRadioButton = radioButtons.find { it.isChecked }

        if (checkedRadioButton != null) {
            val answer = checkedRadioButton.text.toString().trim()
            if (quiz.checkAnswer(answer)) {
                Toast.makeText(this, "Correcto", Toast.LENGTH_SHORT).show()
                points++
            } else {
                Toast.makeText(this, "Incorrecto", Toast.LENGTH_SHORT).show()
            }
            resetCountDownTimer()
            mostrarSiguientePregunta()
        } else {
            Toast.makeText(this, "Selecciona una opción", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createCountDownTimer(duration: Long): CountDownTimer {
        return object : CountDownTimer(duration, 1000) {
            @SuppressLint("SetTextI18n")
            override fun onTick(millisUntilFinished: Long) {
                txtTimer.text = "Tiempo restante: ${millisUntilFinished / 1000} s"
            }

            override fun onFinish() {
                Toast.makeText(this@QuizOneActivity, "Se acabó el tiempo", Toast.LENGTH_SHORT).show()
                resetCountDownTimer()
                mostrarSiguientePregunta()
            }
        }
    }

    private fun resetCountDownTimer() {
        countDownTimer.cancel()
        countDownTimer.start()
    }

}
