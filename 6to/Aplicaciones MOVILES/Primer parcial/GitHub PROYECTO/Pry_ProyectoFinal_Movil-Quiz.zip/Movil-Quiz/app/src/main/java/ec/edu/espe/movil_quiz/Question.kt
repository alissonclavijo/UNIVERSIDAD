package ec.edu.espe.movil_quiz

data class Question(val text: String, val options: List<String>, val correctAnswer: String)

