package ec.edu.espe.movil_quiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnQuizOne = findViewById<Button>(R.id.btnQuizOne)
        btnQuizOne.setOnClickListener {
            startActivity(Intent(this, QuizOneActivity::class.java))
        }

        val btnQuizTwo = findViewById<Button>(R.id.btnQuizTwo)
        btnQuizTwo.setOnClickListener {
            startActivity(Intent(this, QuizTwoActivity::class.java))
        }
    }
}