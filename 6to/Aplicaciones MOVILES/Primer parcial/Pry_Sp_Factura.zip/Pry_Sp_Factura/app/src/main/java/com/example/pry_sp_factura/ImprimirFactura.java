package com.example.pry_sp_factura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ImprimirFactura extends AppCompatActivity {
    TextView lblRcantidad, lblRPrecio, lblRTotal, lblRSubTotal, lblRIva, lblRTipo, lblRMarca;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imprimir_factura);

        /*Bundle*/
        Bundle extras=getIntent().getExtras();
        if(extras!=null){
            String tipo=extras.getString("tipo");
            String marca=extras.getString("marca");
            String cantidad=extras.getString("cantidad");
            String precio=extras.getString("precio");
            String subtotal=extras.getString("subtotal");
            String iva=extras.getString("iva");
            String total=extras.getString("total");

            /*Referencias*/

            lblRcantidad=findViewById(R.id.tv_r_cantidad);
            lblRPrecio=findViewById(R.id.tv_r_preciou);
            lblRMarca=findViewById(R.id.tv_r_marca);
            lblRTipo=findViewById(R.id.tv_r_tipo);
            lblRSubTotal=findViewById(R.id.tv_r_preciot);
            lblRIva=findViewById(R.id.tv_r_iva);
            lblRTotal=findViewById(R.id.tv_r_totalp);

            /*Establecer valores en la caja de texto*/
            lblRTipo.setText(tipo);
            lblRMarca.setText(marca);
            lblRcantidad.setText(cantidad);
            lblRPrecio.setText(precio);
            lblRSubTotal.setText(subtotal);
            lblRIva.setText(iva);
            lblRTotal.setText(total);
        }

    }
}