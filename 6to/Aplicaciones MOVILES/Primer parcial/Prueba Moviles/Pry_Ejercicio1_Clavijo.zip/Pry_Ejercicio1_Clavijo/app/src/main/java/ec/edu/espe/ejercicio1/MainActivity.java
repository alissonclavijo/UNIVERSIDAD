package ec.edu.espe.ejercicio1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtVelocidad;
    EditText txtTiempo;
    TextView lblResultado;

    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtVelocidad = findViewById(R.id.txtVelocidad);
        txtTiempo = findViewById(R.id.txtTiempo);
        btnCalcular = findViewById(R.id.btnCalcular);
        lblResultado = findViewById(R.id.lblResult);

        btnCalcular.setOnClickListener(v -> {
            double velocidad = Double.parseDouble(txtVelocidad.getText().toString());
            double tiempo = Double.parseDouble(txtTiempo.getText().toString());
            double resultado = velocidad * tiempo;
            lblResultado.setText(String.valueOf(resultado));
        });
    }

    private void calcular() {
        if (txtVelocidad.getText().toString().isEmpty() || txtTiempo.getText().toString().isEmpty()) {
            Toast.makeText(this, "Ingrese los datos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!txtVelocidad.getText().toString().matches("[0-9]+") || !txtTiempo.getText().toString().matches("[0-9]+")) {
            Toast.makeText(this, "Ingrese solo números", Toast.LENGTH_SHORT).show();
            return;
        }

        double velocidad = Double.parseDouble(txtVelocidad.getText().toString());
        double tiempo = Double.parseDouble(txtTiempo.getText().toString());
        double resultado = velocidad * tiempo;

        lblResultado.setText(String.valueOf(resultado));
    }

    private double calcularDistancia(double velocidad, double tiempo) {
        return velocidad * tiempo;
    }
}