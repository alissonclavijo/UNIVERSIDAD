package ec.edu.espe.movil_quiz

class Quiz(val questions: List<Question>) {
    private var shuffledQuestions: List<Question> = questions.shuffled()
    private var currentQuestionIndex = 0

    fun getNextRandomQuestion(): Question? {
        if (currentQuestionIndex < shuffledQuestions.size) {
            val randomIndex = currentQuestionIndex++
            return shuffledQuestions[randomIndex]
        }
        return null
    }

    fun checkAnswer(answer: String?): Boolean {
        if (answer == shuffledQuestions[currentQuestionIndex - 1].correctAnswer) {
            return true
        }
        return false
    }
}